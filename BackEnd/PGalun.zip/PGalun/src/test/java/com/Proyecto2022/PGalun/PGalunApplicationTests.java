package com.Proyecto2022.PGalun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PGalunApplicationTests {

	@Test
	void contextLoads() {
	}

}
