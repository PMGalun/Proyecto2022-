package com.Proyecto2022.PGalun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PGalunApplication {

	public static void main(String[] args) {
		SpringApplication.run(PGalunApplication.class, args);
	}

}
